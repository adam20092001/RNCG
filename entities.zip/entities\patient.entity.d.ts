import { User } from 'src/users/entities/user.entity';
import { Prediction } from 'src/predictions/entities/prediction.entity';
export declare class Patient {
    id: number;
    name: string;
    lastname: string;
    age: number;
    sex: string;
    dni: string;
    disable: boolean;
    user: User;
    predictions: Prediction[];
}
